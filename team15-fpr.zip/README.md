# DL project
Course Project of Deep Learning (AI5100) by Dr. Sumohana S. Channappayya 
## Enhancing Image Segmentation: A Comparative Study

Dataset - [Flood Segmentation dataset](https://www.kaggle.com/datasets/faizalkarim/flood-area-segmentation/data)

Contributions
- Aaryan - Maskformer
- Darpan - TransUnet
- Aayush - CNNG, Graph-FCN
- Varun - UNet++